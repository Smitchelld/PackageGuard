#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "driver/gpio.h"

#include "screen_driver.h"
#include "font.h" 

#define TAG "LIBRARY_DEMO"


#define I2C_SDA_PIN 8
#define I2C_SCL_PIN 9


const bool icon_lock[8][8] = {
    {0, 0, 1, 1, 1, 1, 0, 0},
    {0, 1, 0, 0, 0, 0, 1, 0},
    {0, 1, 0, 0, 0, 0, 1, 0},
    {1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 0, 1, 1, 0, 1, 1},
    {1, 1, 0, 1, 1, 0, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1},
    {0, 0, 0, 0, 0, 0, 0, 0}
};

// ==========================================
// DEMO TASK - SHOWCASE ALL FEATURES
// ==========================================
void demo_task(void *arg) {
    ESP_LOGI(TAG, "Starting Library Demo Loop...");

    while (1) {
        // ------------------------------------------------
        // 1. TEXT AND PIXELS
        // ------------------------------------------------
        screen_clear_buffer();
        screen_write_text(0, 0, "1. BASIC TEXT");
        screen_write_text(10, 20, "Hello World!");
        screen_write_text(10, 30, "Custom Driver");
        
        for(int x=0; x<128; x++) { 
            screen_put_pixel(x, 63, 1);
            screen_put_pixel(x, 50, 1);
        }
        
        screen_refresh();
        vTaskDelay(pdMS_TO_TICKS(2000));

        // ------------------------------------------------
        // 2. CUSTOM BITMAPS (BOOL ARRAY)
        // ------------------------------------------------
        screen_clear_buffer();
        screen_write_text(0, 0, "2. BOOL BITMAPS");
        
        screen_draw_bitmap(10, 20, 8, 8, (const bool*)icon_lock);
        screen_draw_bitmap(30, 20, 8, 8, (const bool*)icon_lock);
        screen_draw_bitmap(50, 20, 8, 8, (const bool*)icon_lock);
        
        screen_refresh();
        vTaskDelay(pdMS_TO_TICKS(2000));

        // ------------------------------------------------
        // 3. HARDWARE INVERSION
        // ------------------------------------------------
        screen_write_text(0, 40, "3. INVERT MODE");
        screen_refresh();
        vTaskDelay(pdMS_TO_TICKS(500));
        
        for(int i=0; i<3; i++) {
            screen_invert(true); 
            vTaskDelay(pdMS_TO_TICKS(300));
            screen_invert(false);
            vTaskDelay(pdMS_TO_TICKS(300));
        }
        vTaskDelay(pdMS_TO_TICKS(1000));

        // ------------------------------------------------
        // 4. CLIPPING (WINDOW DRAWING)
        // ------------------------------------------------
        screen_clear_buffer();
        screen_write_text(0, 0, "4. TEXT CLIPPING");
        
        for(int y=15; y<30; y++) { 
            screen_put_pixel(20, y, 1); 
            screen_put_pixel(100, y, 1); 
        }

        screen_write_text_clipped(10, 18, "This text is way too long to fit", 20, 100);
        
        screen_refresh();
        vTaskDelay(pdMS_TO_TICKS(2000));

        // ------------------------------------------------
        // 5. HARDWARE SCROLLING
        // ------------------------------------------------
        screen_clear_buffer();
        screen_write_text(0, 20, "5. HW SCROLLING >>>");
        screen_refresh();
        vTaskDelay(pdMS_TO_TICKS(1000));
        
        screen_scroll_right(0, 7, 5);
        vTaskDelay(pdMS_TO_TICKS(3000));
        
        screen_scroll_stop();
        vTaskDelay(pdMS_TO_TICKS(500));

        // ------------------------------------------------
        // 6. CONTRAST CONTROL (DIMMING)
        // ------------------------------------------------
        screen_clear_buffer();
        screen_write_text(30, 30, "6. DIMMING...");
        screen_refresh();
        

        for(int i=255; i>0; i-=5) {
            screen_set_contrast(i);
            vTaskDelay(pdMS_TO_TICKS(10));
        }
        vTaskDelay(pdMS_TO_TICKS(500));

        for(int i=0; i<255; i+=5) {
            screen_set_contrast(i);
            vTaskDelay(pdMS_TO_TICKS(10));
        }
        screen_set_contrast(0xFF);

        // ------------------------------------------------
        // 7. HARDWARE FLIP (ORIENTATION)
        // ------------------------------------------------
        screen_clear_buffer();
        screen_write_text(30, 30, "7. FLIP 180");
        screen_refresh();
        vTaskDelay(pdMS_TO_TICKS(1000));
        
        screen_flip(true);
        vTaskDelay(pdMS_TO_TICKS(2000));
        screen_flip(false);
        vTaskDelay(pdMS_TO_TICKS(1000));

        // ------------------------------------------------
        // 8. SLEEP MODE (POWER SAVE)
        // ------------------------------------------------
        screen_clear_buffer();
        screen_write_text(30, 30, "8. SLEEP NOW...");
        screen_refresh();
        vTaskDelay(pdMS_TO_TICKS(1000));
        
        screen_display_on(false);
        vTaskDelay(pdMS_TO_TICKS(2000));
        screen_display_on(true);
        
    }
}

// ==========================================
// MAIN ENTRY POINT
// ==========================================
void app_main(void) {

    screen_init(I2C_SDA_PIN, I2C_SCL_PIN);
    xTaskCreate(demo_task, "demo", 4096, NULL, 5, NULL);
}